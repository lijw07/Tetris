# Approved art in Godot

Press **F5** to play the game. To open the art gallery, select `scenes/asset_gallery.tscn` and press **F6**. Choose **Screens**, **Game art**, or **UI art**. The screen selector opens each menu; the actual menu buttons also navigate between previews. **Music off/on** auditions Block Hop. **Replay flash** restarts the four-frame clear effect. Scroll the art catalogs to see every asset.

The gallery's Board layout screen is still a static arrangement; the playable game lives in `scenes/main.tscn` (see **Gameplay** below). The Sound slider is saved but drives nothing yet, because the project has no sound-effect assets.

## Gameplay

| Location | Contents |
|---|---|
| `scenes/main.tscn` + `scripts/main.gd` | Entry point: routes the seven menu screens around the live game, plays Block Hop, saves settings and best score to `user://profile.cfg` |
| `scenes/game/gameplay.tscn` + `scripts/game/gameplay.gd` | The live board: gravity, lock delay, DAS/ARR, hold, next, hard/soft drop, line clear flash, game over |
| `scripts/game/` | `Matrix` (10×20 grid + 2 hidden rows), `ActivePiece`, `TetrominoData` (SRS rotations and wall kicks), `PieceBag` (7-bag), `ScoreKeeper`, `Playfield` and `PiecePreview` renderers |

Controls (Project Settings → Input Map): ←/→ or A/D move, ↑/X/W rotate clockwise, Z rotate counter-clockwise, ↓/S soft drop, Space hard drop, C/Shift hold, Esc/P pause. Scoring is 100/300/500/800 × level for 1–4 lines, +1 per soft-dropped row and +2 per hard-dropped row; the level rises every 10 lines.

The overlay screens (pause, restart confirmation, game over) hide their `BoardPreview` so the live board shows through the dim layer. The main menu, game-over and pause screens are reused unchanged from the generator; `main.gd` fills in the best score and final stats.

```sh
/Applications/Godot.app/Contents/MacOS/Godot --headless --path . --script tests/gameplay_rules.gd
```

## Scene locations

| Location | Contents |
|---|---|
| `scenes/asset_gallery.tscn` | Project entry point and inspection gallery |
| `scenes/art/game/` | 22 individual game-art scenes: blocks, four-cell pieces, ghost, board, original small panels/buttons/icons, animated clear flash |
| `scenes/art/ui/` | 25 individual UI-art scenes: button states, icons, slider parts, toggles, panels, overlay, keycap, T mark |
| `scenes/ui/` | Three functional native controls: Button, HSlider and CheckButton |
| `scenes/screens/` | Seven native screen compositions: main menu, board art, pause, settings, game over, instructions, restart confirmation |
| `scenes/audio/music.tscn` | Reusable looping Block Hop AudioStreamPlayer |

There are **59 scene files**, including **47 one-per-asset art scenes**. The review contact sheets are documentation, not runtime assets. Menu scenes use native labels, controls and instances of the imported art; they are not full-screen screenshots. Double-click a scene in Godot's FileSystem dock to edit it. F6 previews the selected scene; menu navigation is hosted by the gallery when using F5.

## Reuse contracts

- Blocks are top-left-origin Sprite2D scenes at 24×24 pixels. Tetromino scenes are Node2D roots with four reusable block instances; `cells` metadata records occupied grid cells.
- Board texture: 248×488 including a 4px border; the playable area is 10×20 cells at 24px. This is visual geometry, with no physics bodies or gameplay logic.
- Panels use NinePatchRect with 2px margins. Raw UI asset scenes ignore mouse input; `scenes/ui/` provides interactive controls.
- Screen roots emit `action_requested(action)` and `setting_changed(setting, value)`. The gallery connects these signals. `apply_settings()` updates UI values and ghost visibility.
- `resources/simple_theme.tres` supplies the approved PNG button states, system monospace typography, sliders and toggles. Menlo is preferred on macOS, with fallback fonts elsewhere; no font file is bundled.
- Clear flash: AnimatedSprite2D, four 24px atlas frames, 16 fps, one-shot playback. `replay()` restarts it. The last frame is transparent.
- Music: 44.1 kHz stereo WAV, 25.6 seconds. The music script enables the full-file loop from sample 0 to 1,128,960. `set_enabled()` starts/stops it; `set_level()` controls volume. Gallery playback begins only after the Music button is enabled.
- Standalone screen layouts are authored at 960×640. The gallery scales and centers that canvas when its window changes size.

## Sources and regeneration

The approved sources remain in `outputs/simple-v2/` and `outputs/simple-ui-v3/`. Only their approved individual PNGs and latest Block Hop WAV are copied into `assets/`. Earlier rejected music is not referenced. `assets/approved_manifest.json` maps each asset to its source, scene and SHA-256 hash.

`tools/import_approved_art.py` regenerates the runtime asset copies, individual scenes, native screen compositions, theme and manifest. Edit that generator when changing generated scene layouts, then run it again; direct edits to generated `.tscn` files will otherwise be overwritten. Handwritten behavior is in `scripts/`.

```sh
python3 tools/import_approved_art.py
/Applications/Godot.app/Contents/MacOS/Godot --headless --editor --path . --import
/Applications/Godot.app/Contents/MacOS/Godot --headless --path . --script tests/asset_integration.gd
/Applications/Godot.app/Contents/MacOS/Godot --path . --script tests/visual_review.gd
```

Native rendering checks need a desktop session. Use your Godot executable path on other systems. The import must finish before testing the WAV and PNG resources.

## Verification

`tests/asset_integration.gd` checks copied source hashes, scene loading, texture sizes, four-cell piece geometry, effect playback, native controls, navigation, settings, ghost visibility, music playback/loop setup and gallery fit. Results are in `outputs/godot-review/integration.json`.

`tests/visual_review.gd` captures the seven screens, both ends of the two asset catalogs and a narrower gallery window. Those 12 native captures are in `outputs/godot-review/`. Validation was performed on macOS with Godot 4.7.2 using GL Compatibility; other platforms have not been tested.
