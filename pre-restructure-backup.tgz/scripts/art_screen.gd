extends Control

signal action_requested(action: String)
signal setting_changed(setting: String, value: Variant)

@export var preview_background: bool = false

func _ready() -> void:
	if preview_background:
		for item in find_children("*", "Control", true, false):
			item.mouse_filter = Control.MOUSE_FILTER_IGNORE
			item.focus_mode = Control.FOCUS_NONE
		return
	for child in get_children():
		if child is Button and child.has_meta("action"):
			child.pressed.connect(_request_action.bind(str(child.get_meta("action"))))
			if child.get_meta("initial_focus", false):
				child.grab_focus()
		if child is HSlider and child.has_meta("setting"):
			child.value_changed.connect(_slider_changed.bind(str(child.get_meta("setting"))))
	var toggle := get_node_or_null("GhostToggle") as CheckButton
	if toggle:
		toggle.toggled.connect(func(enabled: bool): setting_changed.emit("ghost", enabled))

func _request_action(action: String) -> void:
	action_requested.emit(action)

func _slider_changed(value: float, setting: String) -> void:
	var readout := get_node_or_null(setting.capitalize() + "Value") as Label
	if readout:
		readout.text = "%d%%" % int(value)
	setting_changed.emit(setting, value)

func apply_settings(values: Dictionary) -> void:
	for setting in ["music", "sound"]:
		var slider := get_node_or_null(setting.capitalize() + "Slider") as HSlider
		if slider:
			slider.set_value_no_signal(float(values.get(setting, 50.0)))
			get_node(setting.capitalize() + "Value").text = "%d%%" % int(slider.value)
	var toggle := get_node_or_null("GhostToggle") as CheckButton
	if toggle:
		toggle.set_pressed_no_signal(bool(values.get("ghost", true)))
	var ghost := get_node_or_null("Ghost") as Node2D
	if ghost:
		ghost.visible = bool(values.get("ghost", true))
	var board := get_node_or_null("BoardPreview")
	if board:
		board.apply_settings(values)

func _unhandled_key_input(event: InputEvent) -> void:
	if preview_background or not event.is_action_pressed("ui_cancel"):
		return
	match name:
		"GameplayArt": action_requested.emit("pause")
		"PAUSED": action_requested.emit("gameplay_art")
		"SETTINGS", "HOWTOPLAY": action_requested.emit("back")
		"RestartConfirm": action_requested.emit("pause")
		_: action_requested.emit("main_menu")
	get_viewport().set_input_as_handled()
