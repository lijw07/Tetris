extends Control

const CANVAS := Vector2(960, 640)
const TITLES := ["Main menu", "Board layout", "Pause", "Settings", "Game over", "How to play", "Restart confirmation"]
const SCREEN_KEYS := ["main_menu", "gameplay_art", "pause", "settings", "game_over", "how_to_play", "restart_confirm"]

var catalog: Dictionary
var settings := {"music": 50.0, "sound": 80.0, "ghost": true}
var current_screen: Control
var current_key := ""
var history: Array[String] = []
var stage: Control
var section_picker: OptionButton
var screen_picker: OptionButton
var music_button: Button
var replay_button: Button
var footer: Label
var music: AudioStreamPlayer
var toolbar: HBoxContainer

func _ready() -> void:
	catalog = JSON.parse_string(FileAccess.get_file_as_string("res://assets/approved_manifest.json"))
	var background := ColorRect.new()
	background.color = Color("25292e")
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var title := Label.new()
	title.text = "FALLING BLOCKS / ART GALLERY"
	title.position = Vector2(16, 12)
	title.add_theme_font_size_override("font_size", 18)
	add_child(title)
	toolbar = HBoxContainer.new()
	toolbar.position = Vector2(16, 44)
	toolbar.add_theme_constant_override("separation", 10)
	add_child(toolbar)
	section_picker = OptionButton.new()
	for title_text in ["Screens", "Game art", "UI art"]:
		section_picker.add_item(title_text)
	section_picker.custom_minimum_size = Vector2(160, 40)
	section_picker.item_selected.connect(_section_selected)
	toolbar.add_child(section_picker)
	screen_picker = OptionButton.new()
	for title_text in TITLES:
		screen_picker.add_item(title_text)
	screen_picker.custom_minimum_size = Vector2(240, 40)
	screen_picker.item_selected.connect(func(index: int): history.clear(); show_screen(SCREEN_KEYS[index], false))
	toolbar.add_child(screen_picker)
	music_button = Button.new()
	music_button.text = "Music off"
	music_button.toggle_mode = true
	music_button.custom_minimum_size = Vector2(136, 40)
	music_button.toggled.connect(_music_toggled)
	toolbar.add_child(music_button)
	replay_button = Button.new()
	replay_button.text = "Replay flash"
	replay_button.custom_minimum_size = Vector2(160, 40)
	replay_button.pressed.connect(replay_effects)
	replay_button.visible = false
	toolbar.add_child(replay_button)
	stage = Control.new()
	stage.name = "Stage"
	stage.size = CANVAS
	add_child(stage)
	footer = Label.new()
	footer.add_theme_color_override("font_color", Color("9ba1a4"))
	footer.add_theme_font_size_override("font_size", 12)
	add_child(footer)
	music = load("res://scenes/audio/music.tscn").instantiate()
	add_child(music)
	music.set_level(settings.music)
	resized.connect(_layout)
	show_screen("main_menu", false)
	_layout()

func _layout() -> void:
	if not stage:
		return
	var factor := minf((size.x - 32.0) / CANVAS.x, (size.y - 132.0) / CANVAS.y)
	factor = maxf(factor, 0.05)
	stage.scale = Vector2.ONE * factor
	stage.position = Vector2((size.x - CANVAS.x * factor) / 2.0, 96.0 + maxf(0.0, (size.y - 132.0 - CANVAS.y * factor) / 2.0))
	footer.position = Vector2(16, size.y - 27)
	# Keep gallery controls reachable when the preview window is narrowed.
	var toolbar_scale := minf(1.0, (size.x - 32.0) / 730.0)
	toolbar.scale = Vector2.ONE * maxf(toolbar_scale, 0.1)

func _clear_stage() -> void:
	current_screen = null
	for child in stage.get_children():
		stage.remove_child(child)
		child.queue_free()

func show_screen(key: String, remember: bool = true) -> void:
	if not catalog.screens.has(key):
		return
	if remember and not current_key.is_empty():
		history.append(current_key)
	_clear_stage()
	current_key = key
	section_picker.select(0)
	screen_picker.visible = true
	replay_button.visible = false
	screen_picker.select(SCREEN_KEYS.find(key))
	current_screen = load("res://" + str(catalog.screens[key])).instantiate()
	stage.add_child(current_screen)
	current_screen.action_requested.connect(_action_requested)
	current_screen.setting_changed.connect(_setting_changed)
	current_screen.apply_settings(settings)
	footer.text = "Menu art preview. Play opens the board layout; falling-block gameplay comes next."
	_layout()

func _action_requested(action: String) -> void:
	if action == "quit":
		get_tree().quit()
	elif action == "back":
		var destination: String = history.pop_back() if not history.is_empty() else "main_menu"
		show_screen(destination, false)
	else:
		show_screen(action)

func _setting_changed(setting: String, value: Variant) -> void:
	settings[setting] = value
	if setting == "music":
		music.set_level(float(value))

func _music_toggled(enabled: bool) -> void:
	music.set_enabled(enabled)
	music_button.text = "Music on" if enabled else "Music off"

func _section_selected(index: int) -> void:
	if index == 0:
		show_screen("main_menu", false)
	else:
		show_catalog("game" if index == 1 else "ui")

func show_catalog(group: String) -> void:
	_clear_stage()
	current_key = ""
	history.clear()
	section_picker.select(1 if group == "game" else 2)
	screen_picker.visible = false
	replay_button.visible = group == "game"
	var scroll := ScrollContainer.new()
	scroll.name = "CatalogScroll"
	scroll.position = Vector2(8, 0)
	scroll.size = Vector2(944, 640)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	stage.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	scroll.add_child(grid)
	for entry in catalog.art:
		if str(entry.group) != group:
			continue
		var card := Control.new()
		card.custom_minimum_size = Vector2(224, 150)
		grid.add_child(card)
		var background := ColorRect.new()
		background.color = Color("1b1e22")
		background.mouse_filter = Control.MOUSE_FILTER_IGNORE
		background.size = card.custom_minimum_size
		card.add_child(background)
		var caption := Label.new()
		caption.text = str(entry.name).replace("_", " ")
		caption.add_theme_font_size_override("font_size", 12)
		caption.position = Vector2(10, 10)
		caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(caption)
		var art: Node = load("res://" + str(entry.scene)).instantiate()
		card.add_child(art)
		var art_size := Vector2(float(entry.get("preview_width", entry.width)), float(entry.get("preview_height", entry.height)))
		var factor := minf(2.0, minf(194.0 / art_size.x, 96.0 / art_size.y))
		if art is NinePatchRect:
			art.size = art_size * factor
		else:
			art.scale = Vector2.ONE * factor
		art.position = Vector2((224.0 - art_size.x * factor) / 2.0, 39.0 + (96.0 - art_size.y * factor) / 2.0)
	footer.text = "Each item is a separate reusable scene. Scroll to inspect the full set."
	_layout()

func replay_effects() -> void:
	for effect in stage.find_children("*", "AnimatedSprite2D", true, false):
		effect.replay()
