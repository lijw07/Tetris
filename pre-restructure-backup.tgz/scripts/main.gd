extends Control

const CANVAS_SIZE := Vector2(960, 640)
const PLAY_ACTION := "gameplay_art"
const SCREENS := {
	"main_menu": preload("res://scenes/screens/main_menu.tscn"),
	"how_to_play": preload("res://scenes/screens/how_to_play.tscn"),
	"settings": preload("res://scenes/screens/settings.tscn"),
	"pause": preload("res://scenes/screens/pause.tscn"),
	"restart_confirm": preload("res://scenes/screens/restart_confirm.tscn"),
	"game_over": preload("res://scenes/screens/game_over.tscn"),
}

var profile := ProfileStore.new()
var current_key := ""
var overlay: Control
var history: Array[String] = []

@onready var stage: Control = $Stage
@onready var gameplay: Control = $Stage/Gameplay
@onready var music: AudioStreamPlayer = $Music


func _ready() -> void:
	profile.load_profile()
	gameplay.action_requested.connect(_on_action_requested)
	gameplay.apply_settings(profile.settings)
	music.set_level(float(profile.settings.music))
	music.set_enabled(true)
	resized.connect(_fit_stage)
	_fit_stage()
	_return_to_menu()


func _fit_stage() -> void:
	var factor := maxf(minf(size.x / CANVAS_SIZE.x, size.y / CANVAS_SIZE.y), 0.05)
	stage.scale = Vector2.ONE * factor
	stage.position = (size - CANVAS_SIZE * factor) / 2.0


func _on_action_requested(action: String) -> void:
	match action:
		"quit":
			get_tree().quit()
		"back":
			_show_screen(history.pop_back() if not history.is_empty() else "main_menu")
		PLAY_ACTION:
			if current_key == "pause":
				_resume_game()
			else:
				_start_game()
		"pause":
			_pause_game()
		"game_over":
			_show_game_over()
		"main_menu":
			_return_to_menu()
		_:
			history.append(current_key)
			_show_screen(action)


func _on_setting_changed(setting: String, value: Variant) -> void:
	profile.change_setting(setting, value)
	gameplay.apply_settings(profile.settings)
	if setting == "music":
		music.set_level(float(value))


func _start_game() -> void:
	_close_overlay()
	gameplay.visible = true
	gameplay.new_game()
	_set_gameplay_running(true)


func _resume_game() -> void:
	_close_overlay()
	_set_gameplay_running(true)


func _pause_game() -> void:
	_set_gameplay_running(false)
	history.clear()
	_show_screen("pause")


func _return_to_menu() -> void:
	_set_gameplay_running(false)
	gameplay.visible = false
	history.clear()
	_show_screen("main_menu")


func _show_game_over() -> void:
	_set_gameplay_running(false)
	history.clear()
	var is_new_best := profile.record_score(gameplay.scores.score)
	_show_screen("game_over")
	overlay.get_node("ScoreValue").text = "%06d" % gameplay.scores.score
	overlay.get_node("Stats").text = "LEVEL %02d   LINES %03d" % [gameplay.scores.level, gameplay.scores.lines]
	if is_new_best:
		overlay.get_node("Subtitle").text = "New best!"


func _show_screen(key: String) -> void:
	_close_overlay()
	current_key = key
	overlay = SCREENS[key].instantiate()
	stage.add_child(overlay)
	overlay.action_requested.connect(_on_action_requested)
	overlay.setting_changed.connect(_on_setting_changed)
	overlay.apply_settings(profile.settings)
	_reveal_live_board(overlay)
	if key == "main_menu":
		overlay.get_node("Best").text = "BEST  %06d" % profile.best_score


func _reveal_live_board(screen: Control) -> void:
	var board_preview := screen.get_node_or_null("BoardPreview") as CanvasItem
	if board_preview:
		board_preview.visible = false


func _close_overlay() -> void:
	current_key = ""
	if overlay:
		stage.remove_child(overlay)
		overlay.queue_free()
		overlay = null


func _set_gameplay_running(running: bool) -> void:
	gameplay.process_mode = Node.PROCESS_MODE_INHERIT if running else Node.PROCESS_MODE_DISABLED
