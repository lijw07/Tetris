"""Build the Godot art catalog from the two approved local review bundles."""
from pathlib import Path
import hashlib, json, shutil

ROOT=Path(__file__).resolve().parents[1]
BG='#25292e';PANEL='#1b1e22';LINE='#52585e';INK='#eeeeea';MUTED='#9ba1a4'
SHAPES={'I':[(0,0),(1,0),(2,0),(3,0)],'O':[(0,0),(1,0),(0,1),(1,1)],'T':[(1,0),(0,1),(1,1),(2,1)],'S':[(1,0),(2,0),(0,1),(1,1)],'Z':[(0,0),(1,0),(1,1),(2,1)],'J':[(0,0),(0,1),(1,1),(2,1)],'L':[(2,0),(0,1),(1,1),(2,1)]}
catalog=[];sources=[]
def write(path,text):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
def color(s,alpha=1):return 'Color('+', '.join(str(round(int(s[i:i+2],16)/255,6)) for i in [1,3,5])+f', {alpha})'
def q(s):return json.dumps(s,ensure_ascii=False)
def extref(n):return f'ExtResource("{n}")'
def vec(x,y):return f'Vector2({x}, {y})'
class Scene:
 def __init__(self,name,typ='Control',rootprops=None):
  self.ext=[];self.sub=[];self.nodes=[];self.cache={};self.node(name,typ,props=rootprops or {})
 def external(self,path,typ):
  if path not in self.cache:
   i=str(len(self.ext)+1);self.cache[path]=i;self.ext.append(f'[ext_resource type="{typ}" path="res://{path}" id="{i}"]')
  return extref(self.cache[path])
 def node(self,name,typ=None,parent=None,props=None,instance=None):
  h=f'[node name="{name}"'
  if typ:h+=f' type="{typ}"'
  if parent is not None:h+=f' parent="{parent}"'
  if instance:h+=f' instance={instance}'
  self.nodes.append(h+']\n'+'\n'.join(f'{k} = {v}' for k,v in (props or {}).items()))
 def root(self,**props):self.nodes[0]+='\n'+'\n'.join(f'{k} = {v}' for k,v in props.items())
 def save(self,path):write(path,'[gd_scene format=3]\n\n'+'\n\n'.join(self.ext+self.sub+self.nodes)+'\n')
def bounds(x,y,w,h):return {'offset_left':x,'offset_top':y,'offset_right':x+w,'offset_bottom':y+h}
def full():return {'layout_mode':3,'anchors_preset':15,'anchor_right':1.0,'anchor_bottom':1.0,'grow_horizontal':2,'grow_vertical':2}
def theme(s):return s.external('resources/simple_theme.tres','Theme')
def label(s,name,text,x,baseline,w,size=16,c=INK,align=0,parent='.'):
 s.node(name,'Label',parent,{**bounds(x,baseline-size-4,w,size+12),'mouse_filter':2,'text':q(text),'theme_override_font_sizes/font_size':size,'theme_override_colors/font_color':color(c),'horizontal_alignment':align})
def rectangle(s,name,x,y,w,h,c,alpha=1,parent='.'):
 s.node(name,'ColorRect',parent,{**bounds(x,y,w,h),'mouse_filter':2,'color':color(c,alpha)})
def instance(s,path,name,x,y,w=None,h=None,parent='.'):
 props={'position':vec(x,y)} if w is None else bounds(x,y,w,h)
 s.node(name,parent=parent,props=props,instance=s.external(path,'PackedScene'))
def panel(s,name,x,y,w,h):instance(s,'scenes/art/ui/dialog_panel.tscn',name,x,y,w,h)
def button(s,name,text,x,y,w=280,action=None,primary=False):
 instance(s,'scenes/ui/button.tscn',name,x,y,w,44)
 s.nodes[-1]+=f'\ntext = {q(text)}'
 if action:s.nodes[-1]+=f'\nmetadata/action = {q(action)}'
 if primary:s.nodes[-1]+='\nmetadata/initial_focus = true'
def screen(name):
 s=Scene(name,rootprops=full());s.root(theme=theme(s),script=s.external('scripts/art_screen.gd','Script'))
 return s
def backdrop(s,overlay=False):
 if overlay:
  instance(s,'scenes/screens/gameplay_art.tscn','BoardPreview',0,0,960,640)
  s.nodes[-1]+='\nmouse_filter = 2\npreview_background = true'
  rectangle(s,'Dim',0,0,960,640,'#000000',.65)
 else:rectangle(s,'Background',0,0,960,640,BG)
def dialog(title,subtitle=None,overlay=False):
 s=screen(title.replace(' ',''));backdrop(s,overlay);panel(s,'Panel',300,104,360,448)
 label(s,'Title',title,300,155,360,24,align=1)
 if subtitle:label(s,'Subtitle',subtitle,300,186,360,12,MUTED,1)
 return s

# Copy only approved individual runtime assets. Keep the review exports intact.
for group,bundle in [('game','simple-v2'),('ui','simple-ui-v3')]:
 source=ROOT/'outputs'/bundle
 for a in json.loads((source/'manifest.json').read_text())['assets']:
  if not a['file'].startswith('assets/'):continue
  src=source/Path(a['file']).with_suffix('.png');stem=src.stem.replace('-','_').lower()
  dest=f'assets/art/{group}/{stem}.png';p=ROOT/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p)
  entry={'name':stem,'group':group,'texture':dest,'scene':f'scenes/art/{group}/{stem}.tscn','width':a['width'],'height':a['height'],'source':str(src.relative_to(ROOT)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()}
  if group=='game' and stem.startswith('piece_'):
   cells=SHAPES[stem[-1].upper()];entry['preview_width']=(max(c[0] for c in cells)+1)*24;entry['preview_height']=(max(c[1] for c in cells)+1)*24
  if stem=='clear_flash':entry['preview_width']=24;entry['preview_height']=24
  catalog.append(entry);sources.append({'source':entry['source'],'destination':dest,'sha256':entry['sha256']})

for a in catalog:
 name=a['name'];group=a['group'];w=a['width'];h=a['height']
 if group=='game' and name.startswith('piece_'):
  k=name[-1].upper();s=Scene(f'Piece{k}','Node2D',{'metadata/cells':f'PackedVector2Array({", ".join(str(n) for xy in SHAPES[k] for n in xy)})','metadata/cell_size':24})
  for i,(x,y) in enumerate(SHAPES[k]):instance(s,f'scenes/art/game/block_{k.lower()}.tscn',f'Cell{i}',x*24,y*24)
 elif name=='clear_flash':
  s=Scene('ClearFlash','AnimatedSprite2D',{'centered':'false','texture_filter':1})
  tex=s.external(a['texture'],'Texture2D')
  for i in range(4):s.sub.append(f'[sub_resource type="AtlasTexture" id="Frame{i}"]\natlas = {tex}\nregion = Rect2({i*24}, 0, 24, 24)')
  frames=', '.join('{"duration": 1.0, "texture": SubResource("Frame'+str(i)+'")}' for i in range(4))
  s.sub.append('[sub_resource type="SpriteFrames" id="Frames"]\nanimations = [{"frames": ['+frames+'], "loop": false, "name": &"clear", "speed": 16.0}]')
  s.root(sprite_frames='SubResource("Frames")',animation='&"clear"',script=s.external('scripts/clear_flash.gd','Script'))
 elif group=='game' and (name.startswith('block_') or name=='ghost'):
  s=Scene(name.title(),'Sprite2D',{'centered':'false','texture_filter':1});s.root(texture=s.external(a['texture'],'Texture2D'))
 else:
  is_panel=name in ['panel','dialog_panel','confirm_panel','hud_panel','keycap']
  s=Scene(name.title().replace('_',''),'NinePatchRect' if is_panel else 'TextureRect',{**bounds(0,0,w,h),'mouse_filter':2})
  s.root(texture=s.external(a['texture'],'Texture2D'))
  if is_panel:s.root(patch_margin_left=2,patch_margin_top=2,patch_margin_right=2,patch_margin_bottom=2)
  else:s.root(expand_mode=1,stretch_mode=0)
 s.save(a['scene'])

# Use original PNG button states for native controls, and native text for labels.
theme_ext=[];theme_sub=[]
for name in ['normal','hover','focus','pressed','disabled']:
 theme_ext.append(f'[ext_resource type="Texture2D" path="res://assets/art/ui/button_{name}.png" id="{name}"]')
 theme_sub.append(f'[sub_resource type="StyleBoxTexture" id="{name}"]\ntexture = ExtResource("{name}")\ntexture_margin_left = 2.0\ntexture_margin_top = 2.0\ntexture_margin_right = 2.0\ntexture_margin_bottom = 2.0\ncontent_margin_left = 14.0\ncontent_margin_right = 14.0\ncontent_margin_top = 8.0\ncontent_margin_bottom = 8.0')
for name in ['toggle_true','toggle_false','slider_thumb']:
 theme_ext.append(f'[ext_resource type="Texture2D" path="res://assets/art/ui/{name}.png" id="{name}"]')
theme_sub+=['[sub_resource type="SystemFont" id="Mono"]\nfont_names = PackedStringArray("Menlo", "DejaVu Sans Mono", "monospace")',
 '[sub_resource type="StyleBoxEmpty" id="Empty"]',
 f'[sub_resource type="StyleBoxFlat" id="Track"]\nbg_color = {color(LINE)}\ncontent_margin_top = 2.0\ncontent_margin_bottom = 2.0',
 f'[sub_resource type="StyleBoxFlat" id="Fill"]\nbg_color = {color(INK)}\ncontent_margin_top = 2.0\ncontent_margin_bottom = 2.0']
props=['default_font = SubResource("Mono")','default_font_size = 15',f'Label/colors/font_color = {color(INK)}']
for typ in ['Button','OptionButton']:
 for name in ['normal','hover','focus','pressed','disabled']:props.append(f'{typ}/styles/{name} = SubResource("{name}")')
 for name,c in [('font_color',INK),('font_hover_color',INK),('font_focus_color',BG),('font_pressed_color',BG),('font_hover_pressed_color',BG),('font_disabled_color','#666d73')]:props.append(f'{typ}/colors/{name} = {color(c)}')
props+=['HSlider/styles/slider = SubResource("Track")','HSlider/styles/grabber_area = SubResource("Fill")','HSlider/styles/grabber_area_highlight = SubResource("Fill")','HSlider/icons/grabber = ExtResource("slider_thumb")','HSlider/icons/grabber_highlight = ExtResource("slider_thumb")','HSlider/icons/grabber_disabled = ExtResource("slider_thumb")','CheckButton/icons/checked = ExtResource("toggle_true")','CheckButton/icons/unchecked = ExtResource("toggle_false")','CheckButton/styles/normal = SubResource("Empty")','CheckButton/styles/hover = SubResource("Empty")','CheckButton/styles/pressed = SubResource("Empty")','CheckButton/styles/focus = SubResource("Empty")',f'CheckButton/colors/font_color = {color(INK)}',f'CheckButton/colors/font_pressed_color = {color(INK)}']
write('resources/simple_theme.tres','[gd_resource type="Theme" format=3]\n\n'+'\n\n'.join(theme_ext+theme_sub)+ '\n\n[resource]\n'+'\n'.join(props)+'\n')
for name,typ,w,h in [('button','Button',280,44),('slider','HSlider',280,24),('toggle','CheckButton',44,24)]:
 s=Scene(name.title(),typ,bounds(0,0,w,h));s.root(theme=theme(s))
 if name=='button':s.root(text='"PLAY"')
 if name=='slider':s.root(value=50.0,step=1.0)
 if name=='toggle':s.root(button_pressed='true')
 s.save(f'scenes/ui/{name}.tscn')

# Editable HUD / gameplay art staging scene. No game rules are implied.
s=screen('GameplayArt');s.root(preview_background='false');backdrop(s)
label(s,'Title','FALLING BLOCKS',356,47,300,24)
instance(s,'scenes/art/game/board.tscn','Board',356,76,248,488)
instance(s,'scenes/art/game/piece_t.tscn','FallingPiece',432,200)
s.node('SettledBlocks','Node2D','.')
rows=['J.........','JJ.....L..','SJ.....L..','SSZ...LL..','OZZT..S.JJ','OOZTT.SS.J','IIIITOOS.J']
for y,row in enumerate(rows,13):
 for x,k in enumerate(row):
  if k!='.':instance(s,f'scenes/art/game/block_{k.lower()}.tscn',f'Cell{x}_{y}',360+x*24,80+y*24,parent='SettledBlocks')
s.node('Ghost','Node2D','.')
for i,(x,y) in enumerate(SHAPES['T']):instance(s,'scenes/art/game/ghost.tscn',f'Cell{i}',432+x*24,440+y*24,parent='Ghost')
label(s,'HoldLabel','HOLD',198,101,128,13,MUTED);instance(s,'scenes/art/ui/hud_panel.tscn','HoldPanel',196,118,128,92);instance(s,'scenes/art/game/piece_o.tscn','HoldPiece',235,140)
for y,title,value in [(101,'SCORE','024800'),(182,'LEVEL','06'),(259,'LINES','048')]:
 label(s,title+'Label',title,636,y,128,13,MUTED);label(s,title+'Value',value,636,y+35,140,26)
label(s,'NextLabel','NEXT',636,354,128,13,MUTED);instance(s,'scenes/art/ui/hud_panel.tscn','NextPanel',636,372,128,92);instance(s,'scenes/art/game/piece_i.tscn','NextPiece',652,403)
button(s,'Pause','PAUSE',636,492,128,'pause')
label(s,'Controls','← → MOVE   ↑ ROTATE   SPACE DROP   C HOLD',260,598,500,12,MUTED)
s.save('scenes/screens/gameplay_art.tscn')

s=screen('MainMenu');backdrop(s);instance(s,'scenes/art/ui/t_mark.tscn','Mark',456,103,48,32)
label(s,'Title','FALLING BLOCKS',260,198,440,30,align=1);label(s,'Subtitle','A LITTLE ROOM TO THINK.',260,229,440,12,MUTED,1)
for i,(title,action) in enumerate([('PLAY','gameplay_art'),('HOW TO PLAY','how_to_play'),('SETTINGS','settings'),('QUIT','quit')]):button(s,title.replace(' ',''),title,340,275+i*58,action=action,primary=i==0)
label(s,'Best','BEST  031200',300,586,360,13,MUTED,1);s.save('scenes/screens/main_menu.tscn')
s=dialog('PAUSED','Take your time.',True)
for i,(title,action) in enumerate([('RESUME','gameplay_art'),('SETTINGS','settings'),('RESTART','restart_confirm'),('MAIN MENU','main_menu')]):button(s,title.replace(' ',''),title,340,222+i*66,action=action,primary=i==0)
label(s,'Hint','ESC TO RESUME',300,523,360,11,MUTED,1);s.save('scenes/screens/pause.tscn')
s=dialog('SETTINGS')
for y,title,value in [(213,'Music',50),(289,'Sound',80)]:
 label(s,title+'Label',title.upper(),340,y,200,13,MUTED);label(s,title+'Value',str(value)+'%',560,y,60,13,align=2)
 instance(s,'scenes/ui/slider.tscn',title+'Slider',340,y+12,280,24);s.nodes[-1]+=f'\nvalue = {value}.0\nmetadata/setting = "{title.lower()}"'
label(s,'GhostLabel','GHOST PIECE',340,386,220,13);instance(s,'scenes/ui/toggle.tscn','GhostToggle',576,367,44,24)
button(s,'Done','DONE',340,461,action='back',primary=True);s.save('scenes/screens/settings.tscn')
s=dialog('GAME OVER','Nice run.',True)
label(s,'ScoreLabel','SCORE',300,242,360,12,MUTED,1);label(s,'ScoreValue','024800',300,290,360,42,align=1);label(s,'Stats','LEVEL 06   LINES 048',300,329,360,13,MUTED,1)
button(s,'PlayAgain','PLAY AGAIN',340,383,action='gameplay_art',primary=True);button(s,'MainMenu','MAIN MENU',340,445,action='main_menu');s.save('scenes/screens/game_over.tscn')
s=dialog('HOW TO PLAY','Fill a row to clear it.')
for i,(key,title) in enumerate([('← / →','Move'),('↑','Rotate'),('↓','Soft drop'),('SPACE','Hard drop'),('C','Hold'),('ESC','Pause')]):
 y=213+i*38;instance(s,'scenes/art/ui/keycap.tscn','Key'+str(i),340,y-20,100,28);label(s,'KeyText'+str(i),key,340,y,100,12,align=1);label(s,'Action'+str(i),title,462,y,170,14)
button(s,'GotIt','GOT IT',340,475,action='back',primary=True);s.save('scenes/screens/how_to_play.tscn')
s=screen('RestartConfirm');backdrop(s,True);instance(s,'scenes/art/ui/confirm_panel.tscn','Panel',260,180,440,280)
label(s,'Title','START AGAIN?',260,234,440,24,align=1);label(s,'Subtitle','Your current run will end.',260,277,440,14,MUTED,1)
button(s,'KeepPlaying','KEEP PLAYING',300,324,360,'pause',True);button(s,'Restart','RESTART',300,382,360,'gameplay_art');s.save('scenes/screens/restart_confirm.tscn')

src=ROOT/'outputs/simple-ui-v3/audio/block-hop.wav';dest=ROOT/'assets/audio/block_hop.wav';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
sources.append({'source':str(src.relative_to(ROOT)),'destination':str(dest.relative_to(ROOT)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
s=Scene('Music','AudioStreamPlayer',{'volume_db':-8.0});s.root(stream=s.external('assets/audio/block_hop.wav','AudioStream'),script=s.external('scripts/music.gd','Script'));s.save('scenes/audio/music.tscn')
s=Scene('AssetGallery',rootprops=full());s.root(theme=theme(s),script=s.external('scripts/asset_gallery.gd','Script'));s.save('scenes/asset_gallery.tscn')
screen_names=['main_menu','gameplay_art','pause','settings','game_over','how_to_play','restart_confirm']
manifest={'approval':'User approved simple-v2 game art and simple-ui-v3 UI/music and explicitly requested Godot scenes.','art':catalog,'sources':sources,'screens':{n:f'scenes/screens/{n}.tscn' for n in screen_names},'controls':['scenes/ui/button.tscn','scenes/ui/slider.tscn','scenes/ui/toggle.tscn'],'music':'scenes/audio/music.tscn','gallery':'scenes/asset_gallery.tscn','board':{'columns':10,'rows':20,'cell_size':24},'engine':'Godot 4.7.2','notes':'Scene compositions use native text/controls. Review overview sheets are documentation, not runtime assets.'}
write('assets/approved_manifest.json',json.dumps(manifest,indent=2)+'\n')
print(f'Imported {len(catalog)} art assets, {len(screen_names)} native screens, 3 controls, music and gallery.')
