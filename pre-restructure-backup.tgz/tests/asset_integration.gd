extends SceneTree

var checks := 0
var failures: Array[String] = []

func _initialize() -> void:
	call_deferred("run")

func check(condition: bool, message: String) -> void:
	checks += 1
	if not condition:
		failures.append(message)
		push_error(message)

func run() -> void:
	var manifest: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/approved_manifest.json"))
	for source in manifest.sources:
		check(FileAccess.get_sha256("res://" + str(source.source)) == str(source.sha256), "Source changed: " + str(source.source))
		check(FileAccess.get_sha256("res://" + str(source.destination)) == str(source.sha256), "Copied bytes differ: " + str(source.destination))
	for item in manifest.art:
		var packed := load("res://" + str(item.scene)) as PackedScene
		check(packed != null, "Cannot load " + str(item.scene))
		if not packed:
			continue
		var art := packed.instantiate()
		root.add_child(art)
		var texture := load("res://" + str(item.texture)) as Texture2D
		check(texture != null and texture.get_size() == Vector2(item.width, item.height), "Texture dimensions: " + str(item.name))
		if str(item.name).begins_with("piece_"):
			check(art.get_child_count() == 4, "Tetromino must contain exactly four blocks")
			var cells: PackedVector2Array = art.get_meta("cells")
			var occupied := {}
			for i in range(4):
				var block := art.get_child(i) as Sprite2D
				check(block != null and block.position == cells[i] * 24, "Incorrect piece cell position")
				occupied[cells[i]] = true
			check(occupied.size() == 4, "Duplicate piece cells")
		if str(item.name) == "clear_flash":
			var frames: SpriteFrames = art.sprite_frames
			check(frames.get_frame_count(&"clear") == 4, "Clear effect frame count")
			check(not frames.get_animation_loop(&"clear"), "Clear effect should play once")
			check(frames.get_animation_speed(&"clear") == 16.0, "Clear effect timing")
			await create_timer(0.35).timeout
			check(art.frame == 3 and not art.is_playing(), "Clear effect did not finish on transparent frame")
			art.replay()
			check(art.frame == 0 and art.is_playing(), "Clear effect replay")
		root.remove_child(art)
		art.free()
	for path in manifest.screens.values():
		var packed := load("res://" + str(path)) as PackedScene
		check(packed != null, "Screen load: " + str(path))
		if packed:
			var screen := packed.instantiate()
			root.add_child(screen)
			await process_frame
			check(screen.has_signal("action_requested"), "Screen navigation signal")
			check(screen.find_children("*", "Label", true, false).size() > 0, "Screen labels must remain editable")
			root.remove_child(screen)
			screen.free()
	for path in manifest.controls:
		var control: Control = load("res://" + str(path)).instantiate()
		check(control is BaseButton or control is Range, "Component must be interactive: " + str(path))
		control.free()
	var gallery: Control = load("res://scenes/asset_gallery.tscn").instantiate()
	root.add_child(gallery)
	await process_frame
	check(gallery.current_key == "main_menu", "Gallery startup")
	check(not gallery.music.playing, "Music should wait for user toggle")
	var stream := gallery.music.stream as AudioStreamWAV
	check(stream != null and stream.mix_rate == 44100, "Imported WAV format")
	check(stream.loop_mode == AudioStreamWAV.LOOP_FORWARD and stream.loop_end == 1128960, "Music loop points")
	check(absf(stream.get_length() - 25.6) < 0.001, "Music duration")
	gallery.music_button.button_pressed = true
	check(gallery.music.playing, "Gallery music toggle starts playback")
	gallery.music_button.button_pressed = false
	check(not gallery.music.playing, "Gallery music toggle stops playback")
	gallery.current_screen.get_node("PLAY").pressed.emit()
	check(gallery.current_key == "gameplay_art", "Main menu Play opens board art")
	gallery.current_screen.get_node("Pause").pressed.emit()
	check(gallery.current_key == "pause", "Board Pause navigation")
	gallery.current_screen.get_node("SETTINGS").pressed.emit()
	check(gallery.current_key == "settings", "Pause Settings navigation")
	gallery.current_screen.get_node("MusicSlider").value = 25.0
	check(gallery.current_screen.get_node("MusicValue").text == "25%", "Music slider readout")
	check(absf(gallery.music.volume_db - (linear_to_db(0.25) - 2.0)) < 0.01, "Music slider volume routing")
	gallery.current_screen.get_node("SoundSlider").value = 65.0
	check(gallery.current_screen.get_node("SoundValue").text == "65%", "Sound slider readout")
	gallery.current_screen.get_node("GhostToggle").button_pressed = false
	gallery.current_screen.get_node("Done").pressed.emit()
	check(gallery.current_key == "pause", "Settings Done returns to caller")
	check(not gallery.current_screen.get_node("BoardPreview/Ghost").visible, "Ghost setting applied to background board")
	gallery.current_screen.get_node("RESUME").pressed.emit()
	check(not gallery.current_screen.get_node("Ghost").visible, "Ghost setting survives navigation")
	gallery.show_screen("settings")
	check(gallery.current_screen.get_node("MusicSlider").value == 25.0, "Settings persist in gallery session")
	for group in ["game", "ui"]:
		gallery.show_catalog(group)
		await process_frame
		var grid: GridContainer = gallery.stage.get_node("CatalogScroll").get_child(0)
		check(grid.get_child_count() == (22 if group == "game" else 25), "Gallery asset count: " + group)
	for dimensions in [Vector2(960, 760), Vector2(1280, 900), Vector2(640, 720)]:
		gallery.size = dimensions
		gallery._layout()
		var extent: Vector2 = gallery.stage.position + gallery.CANVAS * gallery.stage.scale
		check(extent.x <= dimensions.x + 1 and extent.y <= dimensions.y - 27, "Gallery fit: " + str(dimensions))
	gallery.queue_free()
	await process_frame
	await process_frame
	var report := {"checks": checks, "failures": failures, "art_scenes": 47, "screen_scenes": 7, "native_controls": 3, "music_scenes": 1, "gallery_scenes": 1, "engine": Engine.get_version_info().string}
	var output := FileAccess.open("res://outputs/godot-review/integration.json", FileAccess.WRITE)
	output.store_string(JSON.stringify(report, "\t"))
	output.close()
	print("ART_INTEGRATION ", JSON.stringify(report))
	quit(0 if failures.is_empty() else 1)
