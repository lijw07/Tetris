extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func capture(name: String) -> void:
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	var image := root.get_texture().get_image()
	image.save_png("res://outputs/godot-review/" + name + ".png")

func run() -> void:
	root.size = Vector2i(960, 760)
	var gallery: Control = load("res://scenes/asset_gallery.tscn").instantiate()
	root.add_child(gallery)
	await process_frame
	for screen in ["main_menu", "gameplay_art", "pause", "settings", "game_over", "how_to_play", "restart_confirm"]:
		gallery.show_screen(screen, false)
		await capture(screen)
	for group in ["game", "ui"]:
		gallery.show_catalog(group)
		gallery.replay_effects()
		await capture(group + "_assets")
		gallery.stage.get_node("CatalogScroll").scroll_vertical = 1200
		await capture(group + "_assets_bottom")
	gallery.show_screen("main_menu", false)
	root.size = Vector2i(640, 720)
	await create_timer(0.15).timeout
	await capture("compact_gallery")
	print("VISUAL_REVIEW_COMPLETE: 12 native captures")
	gallery.queue_free()
	await process_frame
	quit()
